function color1() {
    document.getElementById("bckgrndClr").style.backgroundColor = "#116D6E";
}

function color2() {
    document.getElementById("bckgrndClr").style.backgroundColor = "#F2D8D8";
}